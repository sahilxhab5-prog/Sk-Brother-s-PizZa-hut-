# SK Brother's PizZa HuT — Flutter Android app starter

This is the first customer-app prototype for SK Brother's PizZa HuT, Salehpat. The supplied shop logo is included in the home screen.

## Included
- Dark red/black restaurant theme
- Menu categories and draft menu/prices
- Cart and automatic total calculation
- Delivery and shop-pickup selection
- Cash on Delivery, JazzCash and EasyPaisa checkout choices
- WhatsApp order handoff to 03188122556

## Important before public launch
1. Confirm every menu item and price; the preloaded menu is a draft based on previously supplied menu details.
2. Add the official logo, food photos, delivery charges, opening hours and delivery area.
3. Configure a secure backend (such as Firebase) for admin login, order storage, status updates and live menu editing.
4. JazzCash/EasyPaisa real-time payment requires merchant onboarding and official gateway credentials. The current options are checkout selections only; they do not collect money.
5. Add privacy policy, terms, app icon, signing key and Play Store listing.

## Generate and run the Android project
Install Flutter SDK and Android Studio. In this folder run:
```bash
flutter create .
flutter pub get
flutter run
```

This is source code, not a signed APK. The cloud admin backend and live payment gateway still need to be connected.
