import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const SKPizzaApp());

const String shopPhone = '923188122556'; // WhatsApp format: country code + number

class PizzaProduct {
  final String name;
  final String category;
  final String size;
  final int price;
  const PizzaProduct(this.name, this.category, this.size, this.price);
  String get displayName => size.isEmpty ? name : '$name ($size)';
}

const products = <PizzaProduct>[
  PizzaProduct('Tikka', 'Pizza', 'Small', 500),
  PizzaProduct('Tikka', 'Pizza', 'Medium', 1000),
  PizzaProduct('Tikka', 'Pizza', 'Large', 1500),
  PizzaProduct('Fajita', 'Pizza', 'Small', 500),
  PizzaProduct('Fajita', 'Pizza', 'Medium', 1000),
  PizzaProduct('Fajita', 'Pizza', 'Large', 1500),
  PizzaProduct('Cheese Lover', 'Pizza', 'Small', 500),
  PizzaProduct('Cheese Lover', 'Pizza', 'Medium', 1000),
  PizzaProduct('Cheese Lover', 'Pizza', 'Large', 1500),
  PizzaProduct('Kabab', 'Pizza', 'Small', 650),
  PizzaProduct('Kabab', 'Pizza', 'Medium', 1300),
  PizzaProduct('Kabab', 'Pizza', 'Large', 1800),
  PizzaProduct('Paneer', 'Pizza', 'Small', 650),
  PizzaProduct('Paneer', 'Pizza', 'Medium', 1200),
  PizzaProduct('Paneer', 'Pizza', 'Large', 1800),
  PizzaProduct('Veg', 'Pizza', 'Small', 500),
  PizzaProduct('Veg', 'Pizza', 'Medium', 1000),
  PizzaProduct('Veg', 'Pizza', 'Large', 1500),
  PizzaProduct('Afghani Tikka', 'Pizza', 'Small', 500),
  PizzaProduct('Afghani Tikka', 'Pizza', 'Medium', 1000),
  PizzaProduct('Afghani Tikka', 'Pizza', 'Large', 1500),
  PizzaProduct('Supreme', 'Pizza', 'Small', 500),
  PizzaProduct('Supreme', 'Pizza', 'Medium', 1000),
  PizzaProduct('Supreme', 'Pizza', 'Large', 1500),
  PizzaProduct('Malai Tikka', 'Pizza', 'Small', 550),
  PizzaProduct('Malai Tikka', 'Pizza', 'Medium', 1050),
  PizzaProduct('Malai Tikka', 'Pizza', 'Large', 1600),
  PizzaProduct("SK Brother's Special", 'Pizza', 'Small', 650),
  PizzaProduct("SK Brother's Special", 'Pizza', 'Medium', 1200),
  PizzaProduct("SK Brother's Special", 'Pizza', 'Large', 1700),
  PizzaProduct('Pepperoni', 'Pizza', 'Small', 600),
  PizzaProduct('Pepperoni', 'Pizza', 'Medium', 1200),
  PizzaProduct('Pepperoni', 'Pizza', 'Large', 1700),
  PizzaProduct('Creamy', 'Pizza', 'Small', 600),
  PizzaProduct('Creamy', 'Pizza', 'Medium', 1200),
  PizzaProduct('Creamy', 'Pizza', 'Large', 1800),
  PizzaProduct('D Pizza', 'Pizza', 'Medium', 1200),
  PizzaProduct('D Pizza', 'Pizza', 'Large', 1700),
  PizzaProduct('Crown Crust', 'Pizza', 'Medium', 1100),
  PizzaProduct('Crown Crust', 'Pizza', 'Large', 1600),
  PizzaProduct('Lawa', 'Pizza', 'Medium', 1500),
  PizzaProduct('Lawa', 'Pizza', 'Large', 2500),
  PizzaProduct('D Kabab', 'Pizza', 'Medium', 1300),
  PizzaProduct('D Kabab', 'Pizza', 'Large', 1800),
  PizzaProduct('Pizza Paratha Chicken', 'Fast Food', '', 450),
  PizzaProduct('Pizza Paratha Veg', 'Fast Food', '', 450),
  PizzaProduct('Pizza Paratha Paneer', 'Fast Food', '', 500),
  PizzaProduct('Broast', 'Fast Food', '', 450),
  PizzaProduct('Leg Piece', 'Fast Food', '', 300),
  PizzaProduct('Chicken Burger', 'Fast Food', '', 250),
  PizzaProduct('Veg & Chicken Burger', 'Fast Food', '', 200),
  PizzaProduct('Shawarma', 'Fast Food', '', 250),
  PizzaProduct('Chapli Burger', 'Fast Food', '', 300),
  PizzaProduct('Paneer Roll', 'Fast Food', '', 250),
  PizzaProduct('Veg & Chicken Roll', 'Fast Food', '', 200),
  PizzaProduct('Kabab', 'Fast Food', '', 400),
  PizzaProduct('Loaded Pasta (Half)', 'Pasta', '', 350),
  PizzaProduct('Loaded Pasta (Full)', 'Pasta', '', 500),
  PizzaProduct('Paneer Pasta (Half)', 'Pasta', '', 450),
  PizzaProduct('Paneer Pasta (Full)', 'Pasta', '', 600),
  PizzaProduct('Paneer Loaded Fries (Half)', 'Sides', '', 450),
  PizzaProduct('Paneer Loaded Fries (Full)', 'Sides', '', 600),
  PizzaProduct('Fries', 'Sides', '', 150),
];

class SKPizzaApp extends StatelessWidget {
  const SKPizzaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "SK Brother's PizZa HuT",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE53935), brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF101010),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF171717), foregroundColor: Colors.white),
      ),
      home: const ShopHome(),
    );
  }
}

class ShopHome extends StatefulWidget {
  const ShopHome({super.key});
  @override
  State<ShopHome> createState() => _ShopHomeState();
}

class _ShopHomeState extends State<ShopHome> {
  String category = 'All';
  final Map<PizzaProduct, int> cart = {};

  int get total => cart.entries.fold(0, (sum, e) => sum + e.key.price * e.value);
  int get count => cart.values.fold(0, (sum, q) => sum + q);

  void add(PizzaProduct p) => setState(() => cart[p] = (cart[p] ?? 0) + 1);

  Future<void> checkout() async {
    if (cart.isEmpty) return;
    final name = TextEditingController();
    final phone = TextEditingController();
    final address = TextEditingController();
    String orderType = 'Delivery';
    String payment = 'Cash on Delivery';

    await showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialog) => AlertDialog(
          title: const Text('Checkout'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Customer name')),
              TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile number')),
              TextField(controller: address, decoration: const InputDecoration(labelText: 'Delivery address / pickup note')),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: orderType,
                decoration: const InputDecoration(labelText: 'Order type'),
                items: ['Delivery', 'Shop Pickup'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
                onChanged: (v) => setDialog(() => orderType = v ?? 'Delivery'),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: payment,
                decoration: const InputDecoration(labelText: 'Payment method'),
                items: ['Cash on Delivery', 'JazzCash', 'EasyPaisa'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
                onChanged: (v) => setDialog(() => payment = v ?? 'Cash on Delivery'),
              ),
              const SizedBox(height: 8),
              Text('Total: Rs. $total', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              const Text('JazzCash / EasyPaisa gateway setup is required for live online payments.', style: TextStyle(fontSize: 11, color: Colors.orangeAccent)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () async {
                if (name.text.trim().isEmpty || phone.text.trim().isEmpty || (orderType == 'Delivery' && address.text.trim().isEmpty)) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill name, phone and delivery address.')));
                  return;
                }
                final lines = cart.entries.map((e) => '${e.key.displayName} x${e.value} = Rs. ${e.key.price * e.value}').join('\n');
                final message = "New order - SK Brother's PizZa HuT%0AName: ${Uri.encodeComponent(name.text)}%0APhone: ${Uri.encodeComponent(phone.text)}%0AType: $orderType%0AAddress: ${Uri.encodeComponent(address.text)}%0APayment: ${Uri.encodeComponent(payment)}%0A%0A${Uri.encodeComponent(lines)}%0ATotal: Rs. $total";
                final uri = Uri.parse('https://wa.me/$shopPhone?text=$message');
                Navigator.pop(dialogContext);
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open WhatsApp.')));
                }
              },
              child: const Text('Send order on WhatsApp'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final categories = ['All', 'Pizza', 'Fast Food', 'Pasta', 'Sides'];
    final visible = products.where((p) => category == 'All' || p.category == category).toList();
    return Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text("SK Brother's PizZa HuT", style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
          Text('SALEHPAT • Fresh & Hot', style: TextStyle(fontSize: 11, color: Colors.white70)),
        ]),
        actions: [
          IconButton(onPressed: checkout, icon: Badge(label: Text('$count'), child: const Icon(Icons.shopping_cart))),
        ],
      ),
      body: Column(children: [
        Container(
          width: double.infinity,
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(colors: [Color(0xFFB71C1C), Color(0xFF321111)]),
          ),
          child: Row(children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.asset('assets/sk_brothers_logo.png', width: 104, height: 104, fit: BoxFit.cover),
            ),
            const SizedBox(width: 14),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('HOT • FRESH • DELICIOUS', style: TextStyle(letterSpacing: 1.2, fontSize: 11)),
              SizedBox(height: 6),
              Text('Your favourite pizza\\nis just a tap away!', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
              SizedBox(height: 6),
              Text('Order for delivery or shop pickup'),
            ])),
          ]),
        ),
        SizedBox(
          height: 46,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 10), children: [
            for (final c in categories)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ChoiceChip(label: Text(c), selected: category == c, onSelected: (_) => setState(() => category = c)),
              ),
          ]),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: visible.length,
            itemBuilder: (context, i) {
              final p = visible[i];
              return Card(
                color: const Color(0xFF1D1D1D),
                margin: const EdgeInsets.only(bottom: 9),
                child: ListTile(
                  leading: CircleAvatar(backgroundColor: const Color(0xFF8E1717), child: Icon(p.category == 'Pizza' ? Icons.local_pizza : Icons.fastfood, color: Colors.white)),
                  title: Text(p.displayName, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('Rs. ${p.price}'),
                  trailing: IconButton(onPressed: () => add(p), icon: const Icon(Icons.add_circle, color: Color(0xFFFF5252), size: 30)),
                ),
              );
            },
          ),
        ),
        if (count > 0)
          SafeArea(
            child: Container(
              padding: const EdgeInsets.all(12),
              color: const Color(0xFF242424),
              child: Row(children: [
                Expanded(child: Text('$count item(s)  •  Rs. $total', style: const TextStyle(fontWeight: FontWeight.bold))),
                FilledButton(onPressed: checkout, child: const Text('Checkout')),
              ]),
            ),
          ),
      ]),
    );
  }
}
